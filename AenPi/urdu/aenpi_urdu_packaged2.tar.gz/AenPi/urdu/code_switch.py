import os
import pickle

_MODEL_DIR  = os.path.join(os.path.dirname(__file__), "_models")
_MODEL_PATH = os.path.join(_MODEL_DIR, "code_switch.pkl")

class CodeSwitchDetector:
    def __init__(self, model_path: str = _MODEL_PATH, auto_load: bool = True):
        self.model_path = model_path
        self.is_fitted = False
        self._ur_vocab = set()
        self._en_vocab = set()
        if auto_load and os.path.exists(model_path):
            self._load()

    def detect(self, text: str) -> list:
        tokens = text.lower().split()
        results = []
        for tok in tokens:
            clean = "".join(c for c in tok if c.isalnum())
            if not clean:
                results.append((tok, "MIX"))
                continue
            if clean in self._ur_vocab:
                results.append((tok, "UR"))
            elif clean in self._en_vocab:
                results.append((tok, "EN"))
            elif self.is_fitted and hasattr(self, "_pipeline") and self._pipeline:
                results.append((tok, str(self._pipeline.predict([clean])[0])))
            else:
                results.append((tok, "MIX"))
        return results

    def spans(self, text: str) -> list:
        tokens = text.split()
        if not tokens: return []
        tags = self.detect(text)
        spans_list = []
        current_lang = tags[0][1]
        current_words = [tokens[0]]
        start_idx = 0
        for i in range(1, len(tokens)):
            if tags[i][1] == current_lang:
                current_words.append(tokens[i])
            else:
                spans_list.append({"text": " ".join(current_words), "lang": current_lang, "start": start_idx, "end": i - 1})
                current_lang = tags[i][1]
                current_words = [tokens[i]]
                start_idx = i
        spans_list.append({"text": " ".join(current_words), "lang": current_lang, "start": start_idx, "end": len(tokens) - 1})
        return spans_list

    def _load(self):
        with open(self.model_path, "rb") as f:
            payload = pickle.load(f)
        self._pipeline = payload["pipeline"]
        self._ur_vocab = payload["ur_vocab"]
        self._en_vocab = payload["en_vocab"]
        self.is_fitted = True
